﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper
{

    /*************************************
     Name: Program
     Purpose: Have all controls on game here
     Notes: Organize code
     ************************************/
    class Gamescreen
    {


    }
}
